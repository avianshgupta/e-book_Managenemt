import Layout from './layout'

export default function Genre() {
    return (
        <>
            <Layout>
                <div></div>
            </Layout>
        </>
    )
}